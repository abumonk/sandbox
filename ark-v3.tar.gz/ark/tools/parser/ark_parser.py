"""
ARK DSL Parser
Парсит .ark файлы → AST (Python dict) → JSON
"""

import json
import sys
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Optional
from lark import Lark, Transformer, v_args, Token, Tree

# ============================================================
# AST DATACLASSES
# ============================================================

@dataclass
class TypedField:
    name: str
    type: dict

@dataclass
class MetaPair:
    key: str
    value: dict

@dataclass
class InPort:
    kind: str = "in_port"
    fields: list = field(default_factory=list)

@dataclass
class OutPort:
    kind: str = "out_port"
    meta: list = field(default_factory=list)
    fields: list = field(default_factory=list)

@dataclass
class ProcessRule:
    kind: str = "process"
    meta: list = field(default_factory=list)
    pre: list = field(default_factory=list)
    post: list = field(default_factory=list)
    body: list = field(default_factory=list)
    description: Optional[str] = None

@dataclass
class DataField:
    kind: str = "data"
    name: str = ""
    type: dict = field(default_factory=dict)
    constraint: Optional[dict] = None
    default: Optional[dict] = None

@dataclass
class EntityDef:
    kind: str = ""  # "abstraction" or "class"
    name: str = ""
    inherits: list = field(default_factory=list)
    data_fields: list = field(default_factory=list)
    in_ports: list = field(default_factory=list)
    out_ports: list = field(default_factory=list)
    processes: list = field(default_factory=list)
    invariants: list = field(default_factory=list)
    temporals: list = field(default_factory=list)
    description: Optional[str] = None

@dataclass
class InstanceDef:
    kind: str = "instance"
    name: str = ""
    class_name: str = ""
    assignments: list = field(default_factory=list)

@dataclass
class IslandDef:
    kind: str = "island"
    name: str = ""
    strategy: Optional[str] = None
    memory: list = field(default_factory=list)
    contains: list = field(default_factory=list)
    in_ports: list = field(default_factory=list)
    out_ports: list = field(default_factory=list)
    processes: list = field(default_factory=list)
    classes: list = field(default_factory=list)
    data_fields: list = field(default_factory=list)
    invariants: list = field(default_factory=list)
    temporals: list = field(default_factory=list)
    description: Optional[str] = None

@dataclass
class BridgeDef:
    kind: str = "bridge"
    name: str = ""
    from_port: str = ""
    to_port: str = ""
    contract: Optional[dict] = None

@dataclass
class RegistryDef:
    kind: str = "registry"
    name: str = ""
    entries: list = field(default_factory=list)

@dataclass
class VerifyDef:
    kind: str = "verify"
    target: str = ""
    checks: list = field(default_factory=list)

@dataclass
class ArkFile:
    imports: list = field(default_factory=list)
    items: list = field(default_factory=list)


# ============================================================
# LARK TRANSFORMER → AST
# ============================================================

class ArkTransformer(Transformer):
    """Converts Lark parse tree → ARK AST dataclasses"""

    # --- Primitives ---

    def IDENT(self, token):
        return str(token)

    def NUMBER(self, token):
        s = str(token)
        return float(s) if '.' in s else int(s)

    def STRING(self, items):
        # STRING matches: "content" → we get the inner content
        return str(items)

    # --- Expressions ---

    def ident_expr(self, items):
        return {"expr": "ident", "name": items[0]}

    def number_expr(self, items):
        return {"expr": "number", "value": items[0]}

    def string_expr(self, items):
        return {"expr": "string", "value": items[0]}

    def true_expr(self, _):
        return {"expr": "bool", "value": True}

    def false_expr(self, _):
        return {"expr": "bool", "value": False}

    def path_expr(self, items):
        return items[0]  # dotted_path already handled

    def paren_expr(self, items):
        return items[0]

    def array_expr(self, items):
        return {"expr": "array", "elements": items[0] if items else []}

    def or_expr(self, items):
        if len(items) == 1:
            return items[0]
        return {"expr": "binop", "op": "or", "left": items[0], "right": items[1]}

    def and_expr(self, items):
        if len(items) == 1:
            return items[0]
        return {"expr": "binop", "op": "and", "left": items[0], "right": items[1]}

    def cmp_expr(self, items):
        if len(items) == 1:
            return items[0]
        return {"expr": "binop", "op": str(items[1]), "left": items[0], "right": items[2]}

    def add_expr(self, items):
        if len(items) == 1:
            return items[0]
        return {"expr": "binop", "op": str(items[1]), "left": items[0], "right": items[2]}

    def mul_expr(self, items):
        if len(items) == 1:
            return items[0]
        return {"expr": "binop", "op": str(items[1]), "left": items[0], "right": items[2]}

    def temporal_expr(self, items):
        return {"expr": "temporal", "op": str(items[0]), "operand": items[1]}

    def not_expr(self, items):
        return {"expr": "unary", "op": "not", "operand": items[0]}

    def fn_call(self, items):
        name = items[0]
        args = items[1] if len(items) > 1 else []
        if isinstance(name, dict) and name.get("expr") == "path":
            name_str = ".".join(name["parts"])
        else:
            name_str = str(name)
        return {"expr": "call", "name": name_str, "args": args}

    def for_all_expr(self, items):
        ty = items[0]
        var = items[1]
        rest = items[2:]
        cond = None
        body = rest[-1] if rest else None
        if len(rest) > 1:
            cond = rest[0]
        return {"expr": "for_all", "type": ty, "var": var, "condition": cond, "body": body}

    # --- Paths ---

    def dotted_path(self, items):
        return {"expr": "path", "parts": [str(i) for i in items]}

    def dotted_path_or_ident(self, items):
        parts = [str(i) for i in items]
        if len(parts) == 1:
            return {"expr": "ident", "name": parts[0]}
        return {"expr": "path", "parts": parts}

    # --- Types ---

    def named_type(self, items):
        return {"type": "named", "name": items[0]}

    def generic_type(self, items):
        return {"type": "generic", "name": items[0], "param": items[1]}

    def array_type(self, items):
        ty = items[0]
        size = items[1] if len(items) > 1 else None
        return {"type": "array", "element": ty, "size": size}

    def type_expr(self, items):
        return items[0]

    # --- Constraints ---

    def range_constraint(self, items):
        return {"constraint": "range", "min": items[0], "max": items[1]}

    def enum_constraint(self, items):
        return {"constraint": "enum", "values": items[0]}

    def constraint(self, items):
        return items[0]

    def default_value(self, items):
        return items[0]

    # --- Meta ---

    def meta_pair(self, items):
        return {"key": items[0], "value": items[1]}

    def meta_pair_list(self, items):
        return list(items)

    def meta_brackets(self, items):
        return items[0] if items else []

    # --- Fields & Lists ---

    def typed_field(self, items):
        return {"name": items[0], "type": items[1]}

    def typed_field_list(self, items):
        return list(items)

    def ident_list(self, items):
        return [str(i) for i in items]

    def expr_list(self, items):
        return list(items)

    # --- Four Primitives ---

    def in_port(self, items):
        fields = items[0] if items else []
        return InPort(fields=fields)

    def empty_meta(self, items):
        return items[0] if items else []

    def out_port(self, items):
        meta = []
        fields = []
        for item in items:
            if isinstance(item, list) and item and isinstance(item[0], dict) and "key" in item[0]:
                meta = item
            elif isinstance(item, list):
                fields = item
        return OutPort(meta=meta, fields=fields)

    def process_rule(self, items):
        meta = []
        rule = ProcessRule()
        for item in items:
            if isinstance(item, list) and item and isinstance(item[0], dict) and "key" in item[0]:
                meta = item
            elif isinstance(item, ProcessRule):
                rule = item
                break
        rule.meta = meta
        return rule

    def process_body(self, items):
        rule = ProcessRule()
        for item in items:
            if isinstance(item, dict):
                if item.get("_stmt") == "pre":
                    rule.pre.append(item["expr"])
                elif item.get("_stmt") == "post":
                    rule.post.append(item["expr"])
                elif item.get("_stmt") == "description":
                    rule.description = item["value"]
                elif item.get("_stmt") == "assignment":
                    rule.body.append(item)
                else:
                    rule.body.append(item)
        return rule

    def pre_stmt(self, items):
        return {"_stmt": "pre", "expr": items[0]}

    def post_stmt(self, items):
        return {"_stmt": "post", "expr": items[0]}

    def data_field(self, items):
        name = items[0]
        ty = items[1]
        constraint = None
        default = None
        for item in items[2:]:
            if isinstance(item, dict) and "constraint" in item:
                constraint = item
            else:
                default = item
        return DataField(name=name, type=ty, constraint=constraint, default=default)

    # --- Statements ---

    def strategy_stmt(self, items):
        return {"_stmt": "strategy", "value": items[0]}

    def memory_stmt(self, items):
        return {"_stmt": "memory", "entries": list(items)}

    def memory_entry(self, items):
        return {"name": items[0], "args": list(items[1:])}

    def contains_stmt(self, items):
        return {"_stmt": "contains", "value": items[0]}

    def description_stmt(self, items):
        return {"_stmt": "description", "value": items[0]}

    def invariant_stmt(self, items):
        return {"_stmt": "invariant", "expr": items[0]}

    def temporal_stmt(self, items):
        return {"_stmt": "temporal", "expr": items[0]}

    def assignment(self, items):
        return {"_stmt": "assignment", "target": items[0], "value": items[1]}

    def for_all_stmt(self, items):
        return {"_stmt": "for_all", "type": items[0], "var": items[1],
                "condition": items[2] if len(items) > 3 else None,
                "body": items[-1]}

    def condition_stmt(self, items):
        return {"_stmt": "condition", "expr": items[0], "body": items[1]}

    # --- Entity definitions ---

    def _collect_entity_members(self, items):
        """Common collector for entity body members"""
        result = {
            "data_fields": [], "in_ports": [], "out_ports": [],
            "processes": [], "invariants": [], "temporals": [],
            "description": None, "classes": [],
        }
        for item in items:
            if isinstance(item, InPort):
                result["in_ports"].append(item)
            elif isinstance(item, OutPort):
                result["out_ports"].append(item)
            elif isinstance(item, ProcessRule):
                result["processes"].append(item)
            elif isinstance(item, DataField):
                result["data_fields"].append(item)
            elif isinstance(item, EntityDef):
                result["classes"].append(item)
            elif isinstance(item, dict):
                s = item.get("_stmt")
                if s == "invariant":
                    result["invariants"].append(item["expr"])
                elif s == "temporal":
                    result["temporals"].append(item["expr"])
                elif s == "description":
                    result["description"] = item["value"]
        return result

    def entity_body(self, items):
        return items

    def entity_member(self, items):
        return items[0]

    def abstraction_def(self, items):
        name = items[0]
        inherits = []
        members = []
        for item in items[1:]:
            if isinstance(item, list) and item and isinstance(item[0], str):
                inherits = item
            elif isinstance(item, list):
                members = item
        m = self._collect_entity_members(members)
        m.pop("classes", None)
        return EntityDef(kind="abstraction", name=name, inherits=inherits, **m)

    def class_def(self, items):
        name = items[0]
        inherits = []
        members = []
        for item in items[1:]:
            if isinstance(item, list) and item and isinstance(item[0], str):
                inherits = item
            elif isinstance(item, list):
                members = item
        m = self._collect_entity_members(members)
        m.pop("classes", None)
        return EntityDef(kind="class", name=name, inherits=inherits, **m)

    def instance_def(self, items):
        name = items[0]
        class_name = items[1]
        assignments = []
        for item in items[2:]:
            if isinstance(item, dict) and item.get("_stmt") == "assignment":
                assignments.append({"target": item["target"], "value": item["value"]})
        return InstanceDef(name=name, class_name=class_name, assignments=assignments)

    def inherits(self, items):
        return items[0]

    # --- Island ---

    def island_def(self, items):
        name = items[0]
        members = items[1] if len(items) > 1 else []
        island = IslandDef(name=name)
        m = self._collect_entity_members(members)
        island.in_ports = m["in_ports"]
        island.out_ports = m["out_ports"]
        island.processes = m["processes"]
        island.data_fields = m["data_fields"]
        island.classes = m["classes"]
        island.invariants = m["invariants"]
        island.temporals = m["temporals"]
        island.description = m["description"]
        for item in members:
            if isinstance(item, dict):
                s = item.get("_stmt")
                if s == "strategy":
                    island.strategy = item["value"]
                elif s == "contains":
                    island.contains = item["value"]
                elif s == "memory":
                    island.memory = item["entries"]
        return island

    def island_body(self, items):
        return items

    def island_member(self, items):
        return items[0]

    # --- Bridge ---

    def bridge_def(self, items):
        name = items[0]
        bridge = BridgeDef(name=name)
        for item in items[1:]:
            if isinstance(item, dict):
                s = item.get("_stmt")
                if s == "from":
                    bridge.from_port = item["value"]
                elif s == "to":
                    bridge.to_port = item["value"]
                elif s == "contract":
                    bridge.contract = item
        return bridge

    def bridge_body(self, items):
        return items

    def from_stmt(self, items):
        path = items[0]
        if isinstance(path, dict) and path.get("expr") == "path":
            return {"_stmt": "from", "value": ".".join(path["parts"])}
        return {"_stmt": "from", "value": str(path)}

    def to_stmt(self, items):
        path = items[0]
        if isinstance(path, dict) and path.get("expr") == "path":
            return {"_stmt": "to", "value": ".".join(path["parts"])}
        return {"_stmt": "to", "value": str(path)}

    def contract_block(self, items):
        inv = []
        temp = []
        for item in items:
            if isinstance(item, dict):
                if item.get("_stmt") == "invariant":
                    inv.append(item["expr"])
                elif item.get("_stmt") == "temporal":
                    temp.append(item["expr"])
        return {"_stmt": "contract", "invariants": inv, "temporals": temp}

    def contract_member(self, items):
        return items[0]

    # --- Registry ---

    def registry_def(self, items):
        name = items[0]
        entries = [i for i in items[1:] if isinstance(i, dict)]
        return RegistryDef(name=name, entries=entries)

    def register_stmt(self, items):
        name = items[0]
        meta = items[1] if len(items) > 1 else []
        return {"name": name, "meta": meta}

    # --- Verify ---

    def verify_def(self, items):
        target = items[0]
        checks = [i for i in items[1:] if isinstance(i, dict)]
        return VerifyDef(target=target, checks=checks)

    def check_stmt(self, items):
        return {"name": items[0], "expr": items[1]}

    # --- Import ---

    def item(self, items):
        return items[0]

    def import_stmt(self, items):
        path = items[0]
        if isinstance(path, dict) and path.get("expr") == "path":
            return path["parts"]
        return [str(path)]

    # --- Top level ---

    def start(self, items):
        imports = []
        ark_items = []
        for item in items:
            if isinstance(item, list) and item and isinstance(item[0], str):
                imports.append(item)
            elif isinstance(item, (EntityDef, InstanceDef, IslandDef,
                                   BridgeDef, RegistryDef, VerifyDef)):
                ark_items.append(item)
        return ArkFile(imports=imports, items=ark_items)


# ============================================================
# PARSER API
# ============================================================

_GRAMMAR_PATH = Path(__file__).parent / "ark_grammar.lark"

def get_parser() -> Lark:
    """Create or return cached Lark parser"""
    grammar_text = _GRAMMAR_PATH.read_text()
    return Lark(grammar_text, parser="earley", propagate_positions=True)

def parse(source: str) -> ArkFile:
    """Parse .ark source → ArkFile AST"""
    parser = get_parser()
    tree = parser.parse(source)
    transformer = ArkTransformer()
    return transformer.transform(tree)

def to_json(ark_file: ArkFile) -> str:
    """Serialize ArkFile → JSON"""
    def convert(obj):
        if hasattr(obj, '__dataclass_fields__'):
            return asdict(obj)
        elif isinstance(obj, list):
            return [convert(i) for i in obj]
        elif isinstance(obj, dict):
            return {k: convert(v) for k, v in obj.items()}
        return obj
    return json.dumps(convert(ark_file), indent=2, ensure_ascii=False)


# ============================================================
# CLI
# ============================================================

def main():
    if len(sys.argv) < 2:
        print("Usage: python ark_parser.py <file.ark> [--json] [--tree]")
        sys.exit(1)

    filepath = Path(sys.argv[1])
    source = filepath.read_text(encoding="utf-8")

    if "--tree" in sys.argv:
        # Raw parse tree (for debugging grammar)
        parser = get_parser()
        tree = parser.parse(source)
        print(tree.pretty())
    else:
        # Full AST → JSON
        ark_file = parse(source)
        print(to_json(ark_file))

if __name__ == "__main__":
    main()
