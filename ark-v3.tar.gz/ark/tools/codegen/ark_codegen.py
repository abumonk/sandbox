"""
ARK Codegen
Генерирует код из ARK AST:
  - Rust structs (SoA для tensor-островов, AoS для code-островов)
  - C++ classes (UE5-compatible)
  - Protobuf (для сетевых мостов)

Pipeline:  .ark → parse → AST(JSON) → codegen → .rs / .h / .proto
"""

import json
import sys
from pathlib import Path
from typing import Optional
from dataclasses import dataclass

# ============================================================
# TYPE MAPPING
# ============================================================

RUST_TYPES = {
    "Float": "f32", "Float16": "f16", "Int": "i32", "Uint64": "u64",
    "Bool": "bool", "String": "String", "Path": "PathBuf",
    "Vec2": "Vec2", "Vec3": "Vec3", "Vec4": "Vec4",
    "Quat": "Quat", "Mat4": "Mat4", "AABB": "AABB",
    "Transform": "Transform", "DeltaTime": "DeltaTime",
    "EntityId": "EntityId", "ServerId": "ServerId", "PlayerId": "PlayerId",
}

CPP_TYPES = {
    "Float": "float", "Float16": "FFloat16", "Int": "int32", "Uint64": "uint64",
    "Bool": "bool", "String": "FString", "Path": "FString",
    "Vec2": "FVector2D", "Vec3": "FVector", "Vec4": "FVector4",
    "Quat": "FQuat", "Mat4": "FMatrix", "AABB": "FBox",
    "Transform": "FTransform", "DeltaTime": "float",
    "EntityId": "uint64", "ServerId": "uint64", "PlayerId": "uint64",
}

PROTO_TYPES = {
    "Float": "float", "Float16": "float", "Int": "int32", "Uint64": "uint64",
    "Bool": "bool", "String": "string", "Path": "string",
    "Vec2": "Vec2", "Vec3": "Vec3", "Vec4": "Vec4",
    "Quat": "Quat", "Transform": "Transform",
    "EntityId": "uint64", "ServerId": "uint64", "PlayerId": "uint64",
}


def map_type(ty: dict, target: str) -> str:
    """Map ARK type → target language type"""
    types = {"rust": RUST_TYPES, "cpp": CPP_TYPES, "proto": PROTO_TYPES}[target]

    kind = ty.get("type")
    if kind == "named":
        return types.get(ty["name"], ty["name"])
    elif kind == "generic":
        inner = map_type(ty["param"], target)
        outer = ty["name"]
        if target == "rust":
            return f"{outer}<{inner}>"
        elif target == "cpp":
            return f"T{outer}<{inner}>" if outer != "Texture2D" else f"UTexture2D*"
        elif target == "proto":
            return inner  # proto doesn't have generics like this
    elif kind == "array":
        inner = map_type(ty["element"], target)
        size = ty.get("size")
        if target == "rust":
            return f"[{inner}; {size}]" if size else f"Vec<{inner}>"
        elif target == "cpp":
            return f"TArray<{inner}>"
        elif target == "proto":
            return f"repeated {inner}"

    return "Unknown"


# ============================================================
# RUST CODEGEN
# ============================================================

def gen_rust_entity(entity: dict, strategy: str = "code") -> str:
    """Generate Rust code for a class/abstraction"""
    name = entity["name"]
    lines = []

    # Header
    lines.append(f"// Generated from ARK DSL — do not edit manually")
    lines.append(f"// Entity: {entity['kind']} {name}")
    lines.append(f"// Strategy: {strategy}")
    lines.append(f"")

    if strategy == "tensor":
        lines.extend(_gen_rust_soa(entity))
    else:
        lines.extend(_gen_rust_aos(entity))

    # Invariant assertions
    invariants = entity.get("invariants", [])
    if invariants:
        lines.append(f"")
        lines.append(f"impl {name} {{")
        lines.append(f"    /// Check all invariants. Generated from ARK spec.")
        lines.append(f"    #[inline]")
        lines.append(f"    pub fn check_invariants(&self) -> bool {{")
        for i, inv in enumerate(invariants):
            rust_expr = _expr_to_rust(inv, "self.")
            lines.append(f"        let inv_{i} = {rust_expr};")
        all_invs = " && ".join(f"inv_{i}" for i in range(len(invariants)))
        lines.append(f"        {all_invs}")
        lines.append(f"    }}")
        lines.append(f"}}")

    # Process methods (transition functions)
    processes = entity.get("processes", [])
    if processes:
        lines.append(f"")
        lines.append(f"impl {name} {{")
        for pi, proc in enumerate(processes):
            proc_strategy = _get_meta(proc, "strategy", "code")
            proc_name = f"process_{pi}"

            # Input params from @in ports
            in_ports = entity.get("in_ports", [])
            params = []
            for port in in_ports:
                for field in port.get("fields", []):
                    rtype = map_type(field["type"], "rust")
                    params.append(f"{field['name']}: {rtype}")

            param_str = ", ".join(params)
            lines.append(f"    /// Process rule #{pi} (strategy: {proc_strategy})")
            lines.append(f"    #[inline]")
            lines.append(f"    pub fn {proc_name}(&mut self, {param_str}) {{")

            # Debug assertions for preconditions
            for pre in proc.get("pre", []):
                rust_pre = _expr_to_rust(pre, "self.")
                lines.append(f"        debug_assert!({rust_pre}, \"precondition failed\");")

            # Body
            for stmt in proc.get("body", []):
                if isinstance(stmt, dict) and stmt.get("_stmt") == "assignment":
                    target = _expr_to_rust(stmt["target"], "self.")
                    # Handle prime notation: fuel' → self.fuel
                    target = target.replace("'", "")
                    value = _expr_to_rust(stmt["value"], "self.")
                    lines.append(f"        {target} = {value};")

            # Debug assertions for postconditions
            for post in proc.get("post", []):
                rust_post = _expr_to_rust(post, "self.")
                rust_post = rust_post.replace("'", "")
                lines.append(f"        debug_assert!({rust_post}, \"postcondition failed\");")

            lines.append(f"    }}")
        lines.append(f"}}")

    return "\n".join(lines)


def _gen_rust_aos(entity: dict) -> list:
    """AoS struct — standard layout for code strategy"""
    name = entity["name"]
    lines = []

    # Derive macros
    lines.append(f"#[derive(Debug, Clone, Default)]")
    lines.append(f"pub struct {name} {{")

    for df in entity.get("data_fields", []):
        rtype = map_type(df["type"], "rust")
        default = ""
        if df.get("default"):
            default = f"  // default: {_expr_to_rust(df['default'], '')}"
        lines.append(f"    pub {df['name']}: {rtype},{default}")

    lines.append(f"}}")
    return lines


def _gen_rust_soa(entity: dict) -> list:
    """SoA struct — parallel arrays for tensor strategy"""
    name = entity["name"]
    lines = []

    # Individual struct (still needed for single-entity ops)
    lines.extend(_gen_rust_aos(entity))
    lines.append(f"")

    # SoA batch container
    lines.append(f"/// SoA layout for batch processing (tensor strategy)")
    lines.append(f"#[derive(Debug, Clone)]")
    lines.append(f"pub struct {name}Batch {{")
    lines.append(f"    pub count: usize,")
    for df in entity.get("data_fields", []):
        rtype = map_type(df["type"], "rust")
        lines.append(f"    pub {df['name']}: Vec<{rtype}>,")
    lines.append(f"}}")

    # Batch constructor
    lines.append(f"")
    lines.append(f"impl {name}Batch {{")
    lines.append(f"    pub fn with_capacity(cap: usize) -> Self {{")
    lines.append(f"        Self {{")
    lines.append(f"            count: 0,")
    for df in entity.get("data_fields", []):
        lines.append(f"            {df['name']}: Vec::with_capacity(cap),")
    lines.append(f"        }}")
    lines.append(f"    }}")
    lines.append(f"")

    # Batch process stub
    lines.append(f"    /// Batch process all entities. Optimized for SIMD/tensor ops.")
    lines.append(f"    #[inline]")
    lines.append(f"    pub fn process_all(&mut self, dt: f32) {{")
    lines.append(f"        // TODO: SIMD batch update generated from #process[strategy: tensor]")
    lines.append(f"        for i in 0..self.count {{")
    lines.append(f"            // Per-element update (scalar fallback)")
    lines.append(f"            // Replace with AVX2/tensor implementation")
    lines.append(f"        }}")
    lines.append(f"    }}")
    lines.append(f"}}")

    return lines


# ============================================================
# C++ CODEGEN (UE5)
# ============================================================

def gen_cpp_entity(entity: dict, strategy: str = "code") -> tuple:
    """Generate C++ header + source for UE5"""
    name = entity["name"]
    header = []
    source = []

    # Header
    header.append(f"// Generated from ARK DSL — do not edit manually")
    header.append(f"#pragma once")
    header.append(f"")
    header.append(f"#include \"CoreMinimal.h\"")
    header.append(f"#include \"{name}.generated.h\"")
    header.append(f"")

    # UE5 USTRUCT
    header.append(f"USTRUCT(BlueprintType)")
    header.append(f"struct F{name}")
    header.append(f"{{")
    header.append(f"    GENERATED_BODY()")
    header.append(f"")

    for df in entity.get("data_fields", []):
        ctype = map_type(df["type"], "cpp")
        default_val = ""
        if df.get("default"):
            default_val = f" = {_expr_to_cpp(df['default'])}"
        header.append(f"    UPROPERTY(EditAnywhere, BlueprintReadWrite)")
        header.append(f"    {ctype} {df['name']}{default_val};")
        header.append(f"")

    # Check invariants
    header.append(f"    /** Check all invariants. Generated from ARK spec. */")
    header.append(f"    bool CheckInvariants() const;")
    header.append(f"}};")

    # Source
    source.append(f"// Generated from ARK DSL — do not edit manually")
    source.append(f"#include \"{name}.h\"")
    source.append(f"")
    source.append(f"bool F{name}::CheckInvariants() const")
    source.append(f"{{")
    for inv in entity.get("invariants", []):
        cpp_expr = _expr_to_cpp(inv, prefix="")
        source.append(f"    if (!({cpp_expr})) return false;")
    source.append(f"    return true;")
    source.append(f"}}")

    return ("\n".join(header), "\n".join(source))


# ============================================================
# PROTOBUF CODEGEN
# ============================================================

def gen_proto_entity(entity: dict) -> str:
    """Generate .proto message for network bridges"""
    name = entity["name"]
    lines = []

    lines.append(f'syntax = "proto3";')
    lines.append(f"")
    lines.append(f"// Generated from ARK DSL — do not edit manually")
    lines.append(f"")
    lines.append(f"message {name} {{")

    field_num = 1
    for df in entity.get("data_fields", []):
        ptype = map_type(df["type"], "proto")
        lines.append(f"    {ptype} {df['name']} = {field_num};")
        field_num += 1

    lines.append(f"}}")

    # Port messages
    for port_type, ports in [("Input", entity.get("in_ports", [])),
                              ("Output", entity.get("out_ports", []))]:
        for port in ports:
            if port.get("fields"):
                lines.append(f"")
                lines.append(f"message {name}{port_type} {{")
                fn = 1
                for field in port["fields"]:
                    ptype = map_type(field["type"], "proto")
                    lines.append(f"    {ptype} {field['name']} = {fn};")
                    fn += 1
                lines.append(f"}}")

    return "\n".join(lines)


# ============================================================
# ISLAND CODEGEN
# ============================================================

def gen_island(island: dict, target: str = "rust") -> str:
    """Generate code for an entire island"""
    name = island["name"]
    strategy = island.get("strategy", "code")
    lines = []

    lines.append(f"// ============================================================")
    lines.append(f"// Island: {name}")
    lines.append(f"// Strategy: {strategy}")
    lines.append(f"// ============================================================")
    lines.append(f"")

    # Generate contained classes
    for cls in island.get("classes", []):
        if target == "rust":
            lines.append(gen_rust_entity(cls, strategy))
        lines.append(f"")

    # Island struct itself
    if target == "rust":
        lines.append(f"pub struct {name}Island {{")

        for df in island.get("data_fields", []):
            rtype = map_type(df["type"], "rust")
            lines.append(f"    pub {df['name']}: {rtype},")

        # Contained entity batches
        for contained in island.get("contains", []):
            if strategy == "tensor":
                lines.append(f"    pub {contained.lower()}_batch: {contained}Batch,")
            else:
                lines.append(f"    pub {contained.lower()}s: Vec<{contained}>,")

        lines.append(f"}}")

        # Island update
        lines.append(f"")
        lines.append(f"impl {name}Island {{")

        # Input types from @in
        in_fields = []
        for port in island.get("in_ports", []):
            for field in port.get("fields", []):
                rtype = map_type(field["type"], "rust")
                in_fields.append(f"{field['name']}: {rtype}")

        param_str = ", ".join(in_fields)
        lines.append(f"    pub fn update(&mut self, {param_str}) {{")
        if strategy == "tensor":
            lines.append(f"        // Tensor batch processing")
            for contained in island.get("contains", []):
                lines.append(f"        self.{contained.lower()}_batch.process_all(0.016);")
        else:
            lines.append(f"        // Per-entity processing")
        lines.append(f"    }}")
        lines.append(f"}}")

    return "\n".join(lines)


# ============================================================
# EXPRESSION → LANGUAGE TRANSLATORS
# ============================================================

def _expr_to_rust(expr: dict, prefix: str = "") -> str:
    if expr is None:
        return "true"
    kind = expr.get("expr")
    if kind == "number":
        v = expr["value"]
        return f"{v}_f32" if isinstance(v, float) else str(v)
    elif kind == "bool":
        return "true" if expr["value"] else "false"
    elif kind == "string":
        return f'"{expr["value"]}"'
    elif kind == "ident":
        name = expr["name"]
        return f"{prefix}{name}"
    elif kind == "path":
        return f"{prefix}{'.'.join(expr['parts'])}"
    elif kind == "binop":
        l = _expr_to_rust(expr["left"], prefix)
        r = _expr_to_rust(expr["right"], prefix)
        op = expr["op"]
        if op == "→":
            return f"(!{l} || {r})"
        return f"({l} {op} {r})"
    elif kind == "unary":
        o = _expr_to_rust(expr["operand"], prefix)
        return f"(!{o})" if expr["op"] == "not" else f"({o})"
    elif kind == "temporal":
        return _expr_to_rust(expr["operand"], prefix)
    elif kind == "call":
        args = ", ".join(_expr_to_rust(a, prefix) for a in expr.get("args", []))
        return f"{expr['name']}({args})"
    return "/* unknown */"


def _expr_to_cpp(expr: dict, prefix: str = "") -> str:
    if expr is None:
        return "true"
    kind = expr.get("expr")
    if kind == "number":
        v = expr["value"]
        return f"{v}f" if isinstance(v, float) else str(v)
    elif kind == "bool":
        return "true" if expr["value"] else "false"
    elif kind == "ident":
        return f"{prefix}{expr['name']}"
    elif kind == "binop":
        l = _expr_to_cpp(expr["left"], prefix)
        r = _expr_to_cpp(expr["right"], prefix)
        return f"({l} {expr['op']} {r})"
    return "/* unknown */"


def _get_meta(proc: dict, key: str, default: str = "") -> str:
    for m in proc.get("meta", []):
        if isinstance(m, dict) and m.get("key") == key:
            v = m["value"]
            if isinstance(v, dict) and v.get("expr") == "ident":
                return v["name"]
            return str(v)
    return default


# ============================================================
# FULL FILE CODEGEN
# ============================================================

def codegen_file(ast_json: dict, target: str = "rust", out_dir: Path = None) -> dict:
    """Generate code for all entities in an ARK file"""
    results = {}

    for item in ast_json.get("items", []):
        kind = item.get("kind")
        name = item.get("name", "unknown")

        if kind in ("abstraction", "class"):
            strategy = "code"  # default
            if target == "rust":
                code = gen_rust_entity(item, strategy)
                fname = f"{name.lower()}.rs"
                results[fname] = code
            elif target == "cpp":
                h, cpp = gen_cpp_entity(item, strategy)
                results[f"{name}.h"] = h
                results[f"{name}.cpp"] = cpp
            elif target == "proto":
                proto = gen_proto_entity(item)
                results[f"{name.lower()}.proto"] = proto

        elif kind == "island":
            strategy = item.get("strategy", "code")
            if target == "rust":
                code = gen_island(item, "rust")
                results[f"{name.lower()}_island.rs"] = code

            # Also generate for contained classes
            for cls in item.get("classes", []):
                if target == "rust":
                    code = gen_rust_entity(cls, strategy)
                    results[f"{cls['name'].lower()}.rs"] = code

    # Write files
    if out_dir:
        out_dir.mkdir(parents=True, exist_ok=True)
        for fname, content in results.items():
            (out_dir / fname).write_text(content)
            print(f"  → {out_dir / fname}")

    return results


# ============================================================
# CLI
# ============================================================

def main():
    import argparse
    parser = argparse.ArgumentParser(description="ARK Codegen")
    parser.add_argument("input", help=".ark or .json file")
    parser.add_argument("--target", choices=["rust", "cpp", "proto"], default="rust")
    parser.add_argument("--out", help="Output directory", default=None)
    parser.add_argument("--stdout", action="store_true", help="Print to stdout")
    args = parser.parse_args()

    filepath = Path(args.input)

    if filepath.suffix == ".ark":
        sys.path.insert(0, str(Path(__file__).parent.parent / "parser"))
        from ark_parser import parse, to_json
        source = filepath.read_text(encoding="utf-8")
        ark_file = parse(source)
        ast_json = json.loads(to_json(ark_file))
    else:
        ast_json = json.loads(filepath.read_text())

    out_dir = Path(args.out) if args.out else None
    results = codegen_file(ast_json, args.target, out_dir)

    if args.stdout or not out_dir:
        for fname, content in results.items():
            print(f"\n// === {fname} ===")
            print(content)

    print(f"\nGenerated {len(results)} files ({args.target})")


if __name__ == "__main__":
    main()
