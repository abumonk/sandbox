"""
ARK Verifier
Транслирует инварианты и ограничения из ARK AST в Z3 SMT-формулы.
Проверяет:
  1. Инварианты не нарушаются переходами (pre ∧ body → post → invariant)
  2. Ограничения $data выполнимы
  3. Нет конфликтующих инвариантов
"""

import json
import sys
from pathlib import Path
from z3 import (
    Real, Int, Bool, And, Or, Not, Implies, Solver,
    sat, unsat, unknown, RealVal, IntVal
)

# ============================================================
# SYMBOL TABLE
# ============================================================

class SymbolTable:
    """Manages Z3 variables for an entity"""

    def __init__(self):
        self.vars = {}       # name → Z3 var (current state)
        self.vars_next = {}  # name' → Z3 var (next state)

    def add_real(self, name: str):
        self.vars[name] = Real(name)
        self.vars_next[f"{name}'"] = Real(f"{name}_next")
        return self.vars[name]

    def add_int(self, name: str):
        self.vars[name] = Int(name)
        self.vars_next[f"{name}'"] = Int(f"{name}_next")
        return self.vars[name]

    def add_bool(self, name: str):
        self.vars[name] = Bool(name)
        self.vars_next[f"{name}'"] = Bool(f"{name}_next")
        return self.vars[name]

    def get(self, name: str):
        if name in self.vars:
            return self.vars[name]
        if name in self.vars_next:
            return self.vars_next[name]
        # Auto-create as Real if unknown
        return self.add_real(name)

    def get_next(self, name: str):
        key = f"{name}'"
        if key in self.vars_next:
            return self.vars_next[key]
        return self.get(name)


# ============================================================
# EXPR → Z3 TRANSLATOR
# ============================================================

def translate_expr(expr: dict, syms: SymbolTable):
    """Convert ARK AST expression → Z3 expression"""
    if expr is None:
        return True

    kind = expr.get("expr")

    if kind == "number":
        v = expr["value"]
        return RealVal(v) if isinstance(v, float) else IntVal(v)

    elif kind == "bool":
        return expr["value"]

    elif kind == "ident":
        name = expr["name"]
        if name.endswith("'"):
            return syms.get_next(name[:-1])
        return syms.get(name)

    elif kind == "path":
        # e.g., v.fuel → treat as single var for now
        full = ".".join(expr["parts"])
        return syms.get(full)

    elif kind == "binop":
        left = translate_expr(expr["left"], syms)
        right = translate_expr(expr["right"], syms)
        op = expr["op"]
        if op == ">=": return left >= right
        if op == "<=": return left <= right
        if op == ">":  return left > right
        if op == "<":  return left < right
        if op == "==": return left == right
        if op == "!=": return left != right
        if op == "+":  return left + right
        if op == "-":  return left - right
        if op == "*":  return left * right
        if op == "/":  return left / right
        if op in ("and", "∧"): return And(left, right)
        if op in ("or", "∨"):  return Or(left, right)
        if op == "→":  return Implies(left, right)
        raise ValueError(f"Unknown binop: {op}")

    elif kind == "unary":
        operand = translate_expr(expr["operand"], syms)
        op = expr["op"]
        if op == "not": return Not(operand)
        raise ValueError(f"Unknown unary op: {op}")

    elif kind == "temporal":
        # □, ◇ — for model checking, not SMT
        # For SMT, □(P) ≈ P must hold in all reachable states
        # We approximate: just check P
        return translate_expr(expr["operand"], syms)

    elif kind == "call":
        # clamp, length, etc. — approximate as identity for now
        name = expr["name"]
        args = [translate_expr(a, syms) for a in expr.get("args", [])]
        if name == "clamp" and len(args) >= 1:
            return args[0]
        if name == "length" and len(args) >= 1:
            return args[0]  # approximation
        if len(args) >= 1:
            return args[0]
        return RealVal(0)

    elif kind == "for_all":
        # Approximate: check the body expression
        body = expr.get("body")
        if isinstance(body, dict):
            return translate_expr(body, syms)
        return True

    raise ValueError(f"Cannot translate expression: {expr}")


# ============================================================
# CONSTRAINT CHECKER
# ============================================================

def check_data_constraints(data_fields: list) -> list:
    """Check that $data constraints are satisfiable"""
    results = []
    for df in data_fields:
        name = df["name"]
        constraint = df.get("constraint")
        default = df.get("default")

        if constraint is None:
            continue

        s = Solver()
        syms = SymbolTable()
        var = syms.add_real(name)

        if constraint.get("constraint") == "range":
            lo = translate_expr(constraint["min"], syms)
            hi = translate_expr(constraint["max"], syms)
            s.add(var >= lo)
            s.add(var <= hi)

            # Check default is in range
            if default:
                dv = translate_expr(default, syms)
                s2 = Solver()
                s2.add(var == dv)
                s2.add(var >= lo)
                s2.add(var <= hi)
                result = s2.check()
                results.append({
                    "check": f"{name}_default_in_range",
                    "status": "PASS" if result == sat else "FAIL",
                    "detail": f"default={default} in [{constraint['min']}, {constraint['max']}]"
                })

        elif constraint.get("constraint") == "enum":
            values = constraint["values"]
            var_int = syms.add_int(name)
            options = [var_int == translate_expr(v, syms) for v in values]
            s.add(Or(*options))

            if default:
                dv = translate_expr(default, syms)
                s2 = Solver()
                s2.add(var_int == dv)
                s2.add(Or(*options))
                result = s2.check()
                results.append({
                    "check": f"{name}_default_in_enum",
                    "status": "PASS" if result == sat else "FAIL",
                    "detail": f"default={default} in enum"
                })

    return results


def check_invariants_hold(entity: dict) -> list:
    """Check that process rules preserve invariants.
    
    For each process rule:
      pre ∧ body → post → invariant  
    We check: can pre hold AND invariant be violated after transition?
    If UNSAT → invariant always holds (PASS)
    If SAT → found counterexample (FAIL)
    """
    results = []
    syms = SymbolTable()

    # Register all $data as variables
    for df in entity.get("data_fields", []):
        name = df["name"]
        ty = df.get("type", {}).get("name", "Float")
        if ty in ("Int", "Uint64"):
            syms.add_int(name)
        else:
            syms.add_real(name)

        # Add constraints
        c = df.get("constraint")
        if c and c.get("constraint") == "range":
            lo = translate_expr(c["min"], syms)
            hi = translate_expr(c["max"], syms)
            # These are background constraints
            syms.vars[f"_bg_{name}_lo"] = (syms.get(name) >= lo)
            syms.vars[f"_bg_{name}_hi"] = (syms.get(name) <= hi)

    # For each process × each invariant
    for proc in entity.get("processes", []):
        pre_exprs = [translate_expr(p, syms) for p in proc.get("pre", [])]
        post_exprs = [translate_expr(p, syms) for p in proc.get("post", [])]

        for inv in entity.get("invariants", []):
            inv_z3 = translate_expr(inv, syms)
            inv_name = str(inv)[:50]

            s = Solver()

            # Add preconditions (they must hold)
            for p in pre_exprs:
                s.add(p)

            # Try to violate invariant AFTER transition
            # post conditions describe what's true after
            for p in post_exprs:
                s.add(p)

            # Can the invariant be false?
            s.add(Not(inv_z3))

            result = s.check()

            proc_name = next(
                (m["value"] for m in proc.get("meta", [])
                 if isinstance(m, dict) and m.get("key") == "strategy"),
                "unnamed"
            )

            if result == unsat:
                results.append({
                    "check": f"invariant_holds_{inv_name}",
                    "process": proc_name,
                    "status": "PASS",
                    "detail": "Invariant cannot be violated given pre/post conditions"
                })
            elif result == sat:
                model = s.model()
                results.append({
                    "check": f"invariant_holds_{inv_name}",
                    "process": proc_name,
                    "status": "FAIL",
                    "detail": f"Counterexample found: {model}"
                })
            else:
                results.append({
                    "check": f"invariant_holds_{inv_name}",
                    "process": proc_name,
                    "status": "UNKNOWN",
                    "detail": "Z3 could not determine"
                })

    return results


# ============================================================
# MAIN VERIFIER
# ============================================================

def verify_entity(entity: dict) -> list:
    """Run all verification checks on an entity"""
    results = []
    name = entity.get("name", "?")

    print(f"\n{'='*60}")
    print(f"  Verifying: {entity.get('kind', '?')} {name}")
    print(f"{'='*60}")

    # 1. Check $data constraints
    data_results = check_data_constraints(entity.get("data_fields", []))
    results.extend(data_results)

    # 2. Check invariants hold through transitions
    inv_results = check_invariants_hold(entity)
    results.extend(inv_results)

    # Print results
    for r in results:
        icon = "✓" if r["status"] == "PASS" else "✗" if r["status"] == "FAIL" else "?"
        print(f"  {icon} [{r['status']}] {r['check']}")
        if r.get("detail"):
            print(f"    → {r['detail']}")

    return results


def verify_file(ast_json: dict) -> dict:
    """Verify all entities in an ARK file"""
    all_results = {}

    for item in ast_json.get("items", []):
        kind = item.get("kind")
        name = item.get("name", item.get("target", "?"))

        if kind in ("abstraction", "class"):
            results = verify_entity(item)
            all_results[name] = results

        elif kind == "island":
            # Verify island-level invariants
            results = verify_entity(item)
            all_results[name] = results

            # Verify nested classes
            for cls in item.get("classes", []):
                cls_results = verify_entity(cls)
                all_results[f"{name}.{cls.get('name', '?')}"] = cls_results

    # Summary
    total = sum(len(v) for v in all_results.values())
    passed = sum(1 for v in all_results.values() for r in v if r["status"] == "PASS")
    failed = sum(1 for v in all_results.values() for r in v if r["status"] == "FAIL")

    print(f"\n{'='*60}")
    print(f"  SUMMARY: {passed}/{total} passed, {failed} failed")
    print(f"{'='*60}")

    return {
        "entities": all_results,
        "summary": {"total": total, "passed": passed, "failed": failed}
    }


# ============================================================
# CLI
# ============================================================

def main():
    if len(sys.argv) < 2:
        print("Usage: python ark_verify.py <file.ark.json>")
        print("       (pass JSON AST from ark_parser.py)")
        sys.exit(1)

    filepath = Path(sys.argv[1])

    if filepath.suffix == ".ark":
        # Parse first
        sys.path.insert(0, str(Path(__file__).parent.parent / "parser"))
        from ark_parser import parse, to_json
        source = filepath.read_text(encoding="utf-8")
        ark_file = parse(source)
        ast_json = json.loads(to_json(ark_file))
    else:
        ast_json = json.loads(filepath.read_text())

    result = verify_file(ast_json)

    # Optionally save results
    if "--json" in sys.argv:
        out_path = filepath.with_suffix(".verify.json")
        out_path.write_text(json.dumps(result, indent=2, default=str))
        print(f"\nResults saved to {out_path}")


if __name__ == "__main__":
    main()
