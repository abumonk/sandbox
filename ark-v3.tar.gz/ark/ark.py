#!/usr/bin/env python3
"""
ark — unified CLI for the ARK system

Usage:
  ark parse    <file.ark>              → JSON AST
  ark verify   <file.ark>              → Z3 invariant checks
  ark impact   <file.ark> <entity>     → dependency impact analysis
  ark codegen  <file.ark> --target X   → generate Rust/C++/Proto
  ark graph    <file.ark>              → interactive HTML graph
  ark pipeline <file.ark>              → run full pipeline (parse→verify→codegen)
"""

import sys
import os
from pathlib import Path

# Add tools to path
TOOLS = Path(__file__).parent / "tools"
sys.path.insert(0, str(TOOLS / "parser"))
sys.path.insert(0, str(TOOLS / "verify"))
sys.path.insert(0, str(TOOLS / "codegen"))
sys.path.insert(0, str(TOOLS / "visualizer"))


def cmd_parse(args):
    from ark_parser import parse, to_json
    source = Path(args[0]).read_text(encoding="utf-8")
    result = parse(source)
    print(to_json(result))


def cmd_verify(args):
    from ark_verify import verify_file
    from ark_parser import parse, to_json
    import json
    source = Path(args[0]).read_text(encoding="utf-8")
    ark_file = parse(source)
    ast_json = json.loads(to_json(ark_file))
    verify_file(ast_json)


def cmd_impact(args):
    from ark_impact import build_dependency_graph, analyze_impact, print_impact
    from ark_parser import parse, to_json
    import json
    source = Path(args[0]).read_text(encoding="utf-8")
    ark_file = parse(source)
    ast_json = json.loads(to_json(ark_file))
    graph = build_dependency_graph(ast_json)
    impact = analyze_impact(graph, args[1])
    print_impact(impact, args[1])


def cmd_codegen(args):
    from ark_codegen import codegen_file
    from ark_parser import parse, to_json
    import json
    target = "rust"
    out_dir = None
    filepath = args[0]
    for i, a in enumerate(args[1:], 1):
        if a == "--target" and i + 1 < len(args):
            target = args[i + 1]
        if a == "--out" and i + 1 < len(args):
            out_dir = Path(args[i + 1])
    source = Path(filepath).read_text(encoding="utf-8")
    ark_file = parse(source)
    ast_json = json.loads(to_json(ark_file))
    results = codegen_file(ast_json, target, out_dir)
    if not out_dir:
        for fname, content in results.items():
            print(f"\n// === {fname} ===")
            print(content)
    print(f"\nGenerated {len(results)} files ({target})")


def cmd_graph(args):
    from ark_visualizer import generate_graph_data, generate_html
    from ark_parser import parse, to_json
    import json
    filepath = Path(args[0])
    source = filepath.read_text(encoding="utf-8")
    ark_file = parse(source)
    ast_json = json.loads(to_json(ark_file))
    graph_data = generate_graph_data(ast_json)
    html = generate_html(graph_data, f"ARK — {filepath.stem}")
    out = filepath.with_suffix(".html")
    for i, a in enumerate(args[1:]):
        if a == "--out":
            out = Path(args[i + 2])
    out.write_text(html)
    print(f"Graph → {out}")


def cmd_pipeline(args):
    """Full pipeline: parse → verify → codegen"""
    from ark_parser import parse, to_json
    from ark_verify import verify_file
    from ark_codegen import codegen_file
    from ark_visualizer import generate_graph_data, generate_html
    import json

    filepath = Path(args[0])
    target = "rust"
    for i, a in enumerate(args[1:], 1):
        if a == "--target" and i + 1 < len(args):
            target = args[i + 1]

    print(f"{'='*60}")
    print(f"  ARK Pipeline: {filepath.name}")
    print(f"{'='*60}")

    # 1. Parse
    print(f"\n[1/4] Parsing...")
    source = filepath.read_text(encoding="utf-8")
    ark_file = parse(source)
    ast_json = json.loads(to_json(ark_file))
    items = ast_json.get("items", [])
    print(f"  ✓ {len(items)} items parsed")

    # 2. Verify
    print(f"\n[2/4] Verifying...")
    verify_result = verify_file(ast_json)
    summary = verify_result.get("summary", {})
    passed = summary.get("passed", 0)
    total = summary.get("total", 0)
    failed = summary.get("failed", 0)

    if failed > 0:
        print(f"\n  ⚠ {failed} verification failures — codegen will proceed with warnings")

    # 3. Codegen
    print(f"\n[3/4] Generating {target} code...")
    out_dir = filepath.parent / "generated" / target
    results = codegen_file(ast_json, target, out_dir)
    print(f"  ✓ {len(results)} files generated → {out_dir}")

    # 4. Graph
    print(f"\n[4/4] Generating visualization...")
    graph_data = generate_graph_data(ast_json)
    html = generate_html(graph_data, f"ARK — {filepath.stem}")
    graph_path = filepath.with_suffix(".html")
    graph_path.write_text(html)
    print(f"  ✓ Graph → {graph_path}")

    print(f"\n{'='*60}")
    print(f"  Done. {len(items)} items, {passed}/{total} checks passed, {len(results)} files generated")
    print(f"{'='*60}")


COMMANDS = {
    "parse": cmd_parse,
    "verify": cmd_verify,
    "impact": cmd_impact,
    "codegen": cmd_codegen,
    "graph": cmd_graph,
    "pipeline": cmd_pipeline,
}


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        print(__doc__)
        print("Commands:", ", ".join(COMMANDS.keys()))
        sys.exit(1)
    COMMANDS[sys.argv[1]](sys.argv[2:])


if __name__ == "__main__":
    main()
