# CLAUDE.md — Инструкции для Claude Code по проекту ARK

## Что это

ARK (Architecture Kernel) — декларативная система описания игрового движка MMO.
Всё описывается через `.ark` спецификации. Код генерируется, не пишется.
Ты (Claude Code) — основной инструмент разработки. Работай с .ark файлами
напрямую, запускай инструменты, итерируй быстро.

## Первый запуск

```bash
# 1. Клонировать / распаковать проект
cd ~/projects/ark  # или где лежит проект

# 2. Установить Python-зависимости
pip install lark-parser z3-solver

# 3. Проверить что всё работает
python ark.py pipeline specs/test_minimal.ark

# Ожидаемый результат:
# [1/4] Parsing...     ✓ 6 items
# [2/4] Verifying...   1/2 passed, 1 failed (это нормально — тестовый баг)
# [3/4] Codegen...     ✓ 3 files
# [4/4] Graph...       ✓ HTML
```

Если `ark.py pipeline` прошёл — среда готова.

## Структура проекта

```
ark/
├── ark.py                    # ТОЧКА ВХОДА — единый CLI
├── CLAUDE.md                 # ЭТА ИНСТРУКЦИЯ
├── docs/DSL_SPEC.md          # Спецификация языка ARK (ЧИТАЙ ПЕРВЫМ)
│
├── specs/                    # .ark файлы — ЕДИНСТВЕННЫЙ ИСТОЧНИК ИСТИНЫ
│   ├── root.ark              # Якорь. Всё растёт отсюда.
│   ├── test_minimal.ark      # Минимальный тест парсера
│   └── game/
│       └── vehicle_physics.ark  # Пример: Vehicle подсистема
│
├── tools/                    # Python-инструменты (рабочие, проверенные)
│   ├── parser/
│   │   ├── ark_grammar.lark  # Грамматика (Lark EBNF)
│   │   └── ark_parser.py     # Парсер → AST → JSON
│   ├── verify/
│   │   ├── ark_verify.py     # Z3 SMT верификатор
│   │   └── ark_impact.py     # Анализ влияния изменений
│   ├── codegen/
│   │   └── ark_codegen.py    # Генерация Rust / C++ (UE5) / Protobuf
│   └── visualizer/
│       └── ark_visualizer.py # Интерактивный HTML-граф с LOD
│
├── dsl/                      # Rust-реализация (каркас, pest grammar)
│   ├── grammar/ark.pest      # PEG грамматика для Rust
│   ├── stdlib/types.ark      # Стандартные типы
│   └── src/lib.rs            # AST-определения
│
├── codegen/                  # Rust crate (каркас)
├── verify/                   # Rust crate (каркас)
├── runtime/                  # Rust crate (каркас)
├── orchestrator/             # Rust crate (каркас)
├── skills/claude-code/       # Skill-файл
│   └── SKILL.md
└── Cargo.toml                # Rust workspace
```

## Команды CLI

```bash
# Парсинг в JSON AST
python ark.py parse specs/game/vehicle_physics.ark

# Z3 верификация инвариантов
python ark.py verify specs/game/vehicle_physics.ark

# Анализ влияния: "что сломается если поменять Vehicle?"
python ark.py impact specs/test_minimal.ark Vehicle

# Генерация кода (rust | cpp | proto)
python ark.py codegen specs/game/vehicle_physics.ark --target rust
python ark.py codegen specs/game/vehicle_physics.ark --target cpp --out generated/

# Интерактивный граф
python ark.py graph specs/test_minimal.ark

# Полный pipeline: parse → verify → codegen → graph
python ark.py pipeline specs/test_minimal.ark --target rust
```

## Четыре фундаментальных примитива

Запомни — они используются ВЕЗДЕ, на каждом уровне:

```
@in{}           — входной порт (что сущность принимает)
#process[]{}    — правило обработки (что происходит)
@out[]          — выходной порт (что сущность производит)
$data           — состояние (что хранится)
```

## Три уровня сущностей

```
abstraction  — скелет, контракт без реализации
class        — конкретная реализация с $data и #process
instance     — живой объект в runtime
```

## Workflow: как работать с проектом

### Создание новой подсистемы

1. Прочитай `docs/DSL_SPEC.md` для синтаксиса
2. Создай .ark файл в `specs/game/` (или `specs/infra/` для инфраструктуры)
3. Начни с `abstraction` — определи контракт (@in/@out/invariant)
4. Реализуй как `class` — добавь $data, #process, strategy
5. Оберни в `island` — задай strategy для группы, memory, contains
6. Если связан с другим островом — создай `bridge` с `contract`
7. Добавь `verify` блок с проверками
8. Зарегистрируй в `specs/root.ark` → `registry SystemRegistry`
9. Запусти `python ark.py pipeline specs/game/new_system.ark`
10. Если verify нашёл баги — исправь .ark, повтори с шага 9

### Модификация существующей подсистемы

1. Запусти impact ДО изменений: `python ark.py impact file.ark EntityName`
2. Внеси изменения в .ark файл
3. Запусти verify: `python ark.py verify file.ark`
4. Если verify пройден — запусти codegen
5. Если verify не пройден — Z3 покажет контрпример, исправь спеку

### Выбор стратегии для #process

```
strategy: tensor      — когда: однородные данные, массовая обработка, SoA
                        пример: позиции 10000 сущностей, heightmap batch
                        codegen: Rust SoA batch structs + SIMD-ready

strategy: code        — когда: ветвистая логика, условия, мало данных
                        пример: AI поведение, квесты, UI
                        codegen: обычные Rust/C++ классы

strategy: asm_avx2    — когда: hot loop, точно знаем layout, нужен SIMD
                        пример: broadphase коллизий, terrain deform
                        codegen: Rust с #[inline] + intrinsics placeholder

strategy: gpu_compute — когда: параллелизм >1000, texture/buffer данные
                        пример: эрозия, частицы, пост-обработка
                        codegen: WGSL shader stub

strategy: verified    — когда: протокол, контракт, критичная корректность
                        пример: entity handoff, state sync
                        codegen: Rust + Z3 assertions

strategy: script      — когда: часто меняется, не критично по перфу
                        пример: скрипты квестов, конфиг, баланс
                        codegen: Lua/Wren bindings
```

## Приоритеты выполнения

Оркестратор (root.ark → Orchestrator) выбирает способ выполнения:

```
priority 100: script/codegen  — детерминированные операции без AI
priority  80: verify          — Z3 solver, тоже детерминированный
priority  50: agent           — Claude Code, когда нужно рассуждение
```

ПРАВИЛО: если задачу можно выполнить скриптом или codegen — ДЕЛАЙ ТАК.
AI (ты) используется ТОЛЬКО для:
- Проектирование новых .ark спеков
- Решения о стратегии / архитектуре
- Диагностика сложных верификационных ошибок
- Написание нового функционала для tools/

## Текущее состояние и что нужно делать

### Работает сейчас (проверено)
- [x] Парсер: .ark → JSON AST (все 6 типов items)
- [x] Z3 верификатор: $data constraints, invariant checks
- [x] Codegen: Rust (AoS + SoA batch), C++ (UE5 USTRUCT), Protobuf
- [x] Impact analyzer: зависимости, мосты, re-verification
- [x] Визуализатор: HTML граф с 3 LOD-уровнями
- [x] Unified CLI: ark.py с 6 командами
- [x] Полный pipeline: parse → verify → codegen → graph

### Бэклог (по приоритету)

#### Приоритет 1 — Парсер / Codegen глубина
- [ ] Codegen: генерация тел #process (сейчас пустые методы)
- [ ] Codegen: SoA batch process_all() с реальными формулами из #process
- [ ] Codegen: default values в конструкторах Rust-структур
- [ ] Парсер: robustness — обработка ошибок, позиции ошибок в исходнике
- [ ] Парсер: import resolution — загрузка stdlib/types.ark при парсинге
- [ ] Тесты: unit tests для каждого типа .ark сущностей

#### Приоритет 2 — Верификация глубина
- [ ] Verify: трансляция ВСЕХ выражений #process в Z3 (не только pre/post)
- [ ] Verify: проверка bridge contracts (type matching между портами)
- [ ] Verify: temporal properties через bounded model checking
- [ ] `ark diff` — семантический diff двух версий .ark файла

#### Приоритет 3 — Оркестратор
- [ ] Оркестратор: чтение root.ark → реальный execution pipeline
- [ ] Оркестратор: file watcher → auto re-verify → auto re-codegen
- [ ] Оркестратор: задачи для Claude Code через .ark спеки

#### Приоритет 4 — Runtime прототип
- [ ] Runtime: wgpu + winit окно
- [ ] Runtime: ECS (hecs) интеграция с codegen output
- [ ] Runtime: загрузка island → исполнение tick loop из root.ark

#### Приоритет 5 — Перенос на Rust
- [ ] Rust-парсер: подключить pest grammar (уже написана в dsl/grammar/ark.pest)
- [ ] Rust-codegen: перенести логику из Python
- [ ] Rust-verify: Z3 через z3-sys crate

### Игровые подсистемы (создавать по мере готовности tooling)
- [ ] specs/game/terrain_system.ark — Terrain + deformation
- [ ] specs/game/network_layer.ark — MMO dispatcher + entity sync
- [ ] specs/game/audio_mixer.ark — Audio island
- [ ] specs/infra/asset_pipeline.ark — Asset cook pipeline
- [ ] specs/infra/build_system.ark — Build orchestration

## Типичные сессии

### "Создай новый остров для террейна"
```bash
# 1. Ты создаёшь specs/game/terrain_system.ark
# 2. Запусти verify
python ark.py verify specs/game/terrain_system.ark
# 3. Запусти codegen
python ark.py codegen specs/game/terrain_system.ark --target rust --out generated/rust/
# 4. Запусти impact чтобы увидеть связи
python ark.py impact specs/game/terrain_system.ark TerrainSystem
# 5. Обнови root.ark — добавь в registry
# 6. Запусти graph чтобы визуализировать
python ark.py graph specs/game/terrain_system.ark
```

### "Улучши codegen — добавь тела #process"
```bash
# 1. Открой tools/codegen/ark_codegen.py
# 2. Найди gen_rust_entity → _gen_rust_aos / _gen_rust_soa
# 3. В секции "Process methods" — заполни body generation
# 4. Тестируй на specs/test_minimal.ark:
python ark.py codegen specs/test_minimal.ark --target rust
# 5. Проверь что сгенерированный Rust валиден:
#    (если Rust доступен)
#    cd generated && cargo check
```

### "Добавь поддержку нового типа в DSL"
```bash
# 1. Добавь тип в dsl/stdlib/types.ark
# 2. Добавь маппинг в tools/codegen/ark_codegen.py → RUST_TYPES / CPP_TYPES / PROTO_TYPES
# 3. Тестируй: создай .ark файл использующий новый тип
# 4. Запусти pipeline
```

## Принципы при работе

1. **DSL first** — никогда не пиши игровой код напрямую. Сначала .ark, потом codegen.
2. **Verify before codegen** — всегда проверяй инварианты перед генерацией.
3. **Impact before change** — всегда проверяй влияние перед модификацией.
4. **Minimal AI** — если можешь сделать задачу через ark.py — делай. Не рассуждай, выполняй.
5. **One island at a time** — не пытайся собрать всё сразу. Один остров, одна верификация, один codegen.
6. **Root anchors everything** — root.ark всегда актуален. Обновляй registry при добавлении островов.
